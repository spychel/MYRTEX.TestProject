import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { EmployeesService } from '../employees/employees.service';
import { IEmployee } from '../share/models/employee';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.scss']
})
export class DeleteEmployeeComponent implements OnInit {
  @Input() employeeId: number;
  employee: IEmployee;

  constructor(public activeModal: NgbActiveModal, private employeesService: EmployeesService) { }

  ngOnInit(): void {
    this.initialiseEmployee();
  }

  initialiseEmployee() {
    this.employeesService.getEmployee(this.employeeId).subscribe(employee => this.employee = employee, error => console.log(error));
  }
  

}
