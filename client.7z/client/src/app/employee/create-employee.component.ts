import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { EmployeesService } from '../employees/employees.service';
import { IDepartment } from '../share/models/department';
import { IEmployee } from '../share/models/employee';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.scss']
})
export class CreateEmployeeComponent implements OnInit {
  @Input() employeeId: number;
  employee: IEmployee;
  departments: IDepartment[];
  birthdateModified: string;
  hiredateModified: string;
  
  constructor(public activeModal: NgbActiveModal, private employeesService: EmployeesService) { }

  ngOnInit(): void {
    this.initialiseEmployee();
    this.initialiseDepartments();
  }

  initialiseEmployee() {
    this.employeesService.getEmployee(this.employeeId).subscribe(employee => { 
      this.employee = employee;
      this.modifyDates();
    }, 
      error => console.log(error));
  }

  initialiseDepartments() {
    this.employeesService.getDepartments().subscribe(departments => this.departments = departments, error => console.log(error));
  }

  modifyDates() {
    this.birthdateModified = this.modifyDate(this.employee.birthdate);
    this.hiredateModified = this.modifyDate(this.employee.hiredate);
  }

  modifyDate(inputDate: string) : string {
    var temp = inputDate.split('.');
    return temp.reverse().join('-');
  }

}
