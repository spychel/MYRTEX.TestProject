export interface IEmployee {
    id: number;
    name: string;
    birthdate: string;
    hiredate: string;
    salary: number;
    department: string;
}