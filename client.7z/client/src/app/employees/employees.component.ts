import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CreateEmployeeComponent } from '../employee/create-employee.component';
import { DeleteEmployeeComponent } from '../employee/delete-employee.component';
import { EditEmployeeComponent } from '../employee/edit-employee.component';
import { IEmployee } from '../share/models/employee';
import { EmployeesService } from './employees.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss']
})
export class EmployeesComponent implements OnInit {
  employees: IEmployee[];
  sortSelected: string = 'deptAsc';
  nameFilter: string = '';
  deptFilter: string = '';
  salaryFilter: string = '';
  birthdateFilter: string = '';
  hiredateFilter: string = '';

  sorts = [
    { value: "deptAsc", name: "Отдел" },
    { value: "nameAsc", name: "ФИО" },
    { value: "birthdateAsc", name: "Дата рождения" },
    { value: "hiredateAsc", name: "Дата найма" },
    { value: "salaryAsc", name: "Зарплата" }
  ];

  constructor(private employeesService: EmployeesService, private modalService: NgbModal) {}

  ngOnInit(): void {
    this.getEmployees();
  }

  getEmployees() {
    this.employeesService.getEmployees(this.sortSelected, this.nameFilter, this.deptFilter, this.salaryFilter, this.birthdateFilter, this.hiredateFilter)
      .subscribe(employees => this.employees = employees, error => console.log(error));
  }

  onSortSelected(sort: string) {
    this.sortSelected = sort;
    this.getEmployees();
  }

  onFiltersChanged() {
    this.getEmployees();
  }

  onReset() {
    this.nameFilter = '';
    this.deptFilter = '';
    this.salaryFilter = '';
    this.birthdateFilter = '';
    this.hiredateFilter = '';
    this.getEmployees();
  }

  onCreate(event, id: number) {
    const modalRef = this.modalService.open(CreateEmployeeComponent);
    modalRef.componentInstance.employeeId = id;
  }

  onEdit(event, id: number) {
    const modalRef = this.modalService.open(EditEmployeeComponent);
    modalRef.componentInstance.employeeId = id;
  }

  onRemove(event, id: number) {
    const modalRef = this.modalService.open(DeleteEmployeeComponent);
    modalRef.componentInstance.employeeId = id;
  }


}
