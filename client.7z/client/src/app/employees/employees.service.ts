import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { mergeMap } from 'rxjs-compat/operator/mergeMap';
import { Observable } from 'rxjs/Observable';
import { catchError, map, tap } from 'rxjs/operators';
import { IDepartment } from '../share/models/department';
import { IEmployee } from '../share/models/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {
  private urlBase = 'https://localhost:5001/api/';

  constructor(private http: HttpClient) { }

  getEmployees(sort?: string, name?: string, dept?: string, salary?: string, birthdate?: string, hiredate?: string) {
    let params = new HttpParams();

    if(sort)
    {
      params = params.append('Sort', sort);
    }

    if(name)
    {
      params = params.append('Name', name);
    }

    if(dept)
    {
      params = params.append('Department', dept);
    }

    if(salary)
    {
      params = params.append('Salary', salary);
    }

    if(birthdate)
    {
      params = params.append('Birthdate', birthdate);
    }

    if(hiredate)
    {
      params = params.append('Hiredate', hiredate);
    }

    return this.http.get<IEmployee[]>(this.urlBase + 'employees', {observe: 'response', params}).pipe(
        map(response => {
          return response.body;
        })
      );
  }

  getEmployee(id: number) {
    return this.http.get<IEmployee>(this.urlBase + 'employees/' + id);
  }

  getDepartments() {
    return this.http.get<IDepartment[]>(this.urlBase + 'employees/departments');
  }
  
}
