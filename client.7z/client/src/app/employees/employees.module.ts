import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeesComponent } from './employees.component';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CreateEmployeeComponent } from '../employee/create-employee.component';
import { EditEmployeeComponent } from '../employee/edit-employee.component';
import { DeleteEmployeeComponent } from '../employee/delete-employee.component';


@NgModule({
  declarations: [
    EmployeesComponent,
    CreateEmployeeComponent,
    EditEmployeeComponent,
    DeleteEmployeeComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule
  ],
  exports: [
    EmployeesComponent
  ],
  entryComponents: [
    CreateEmployeeComponent,
    EditEmployeeComponent,
    DeleteEmployeeComponent
  ]
})
export class EmployeesModule { }
